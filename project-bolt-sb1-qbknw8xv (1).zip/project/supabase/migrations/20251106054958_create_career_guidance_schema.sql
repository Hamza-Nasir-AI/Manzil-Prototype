/*
  # Create Manzil Career Guidance Schema

  1. New Tables
    - `careers`
      - `id` (uuid, primary key)
      - `title` (text, career title in English)
      - `title_urdu` (text, career title in Urdu)
      - `description` (text, detailed description)
      - `description_urdu` (text, description in Urdu)
      - `category` (text, e.g., Medical, Engineering, Business)
      - `duration_years` (integer, study duration)
      - `average_cost` (integer, estimated cost in PKR)
      - `salary_range_min` (integer, minimum salary)
      - `salary_range_max` (integer, maximum salary)
      - `job_demand` (text, Low/Medium/High)
      - `required_subjects` (text[], array of required subjects)
      - `universities` (text[], array of universities)
      - `entry_tests` (text[], array of entry tests)
      - `created_at` (timestamp)
    
    - `assessment_questions`
      - `id` (uuid, primary key)
      - `question` (text, question in English)
      - `question_urdu` (text, question in Urdu)
      - `type` (text, personality or interest)
      - `category` (text, e.g., analytical, creative, social)
      - `options` (jsonb, array of options)
      - `created_at` (timestamp)
    
    - `user_assessments`
      - `id` (uuid, primary key)
      - `session_id` (text, anonymous session identifier)
      - `answers` (jsonb, user's answers)
      - `results` (jsonb, calculated career matches)
      - `created_at` (timestamp)
    
    - `scholarships`
      - `id` (uuid, primary key)
      - `title` (text, scholarship name)
      - `title_urdu` (text, scholarship name in Urdu)
      - `description` (text)
      - `description_urdu` (text)
      - `type` (text, national or international)
      - `country` (text, destination country)
      - `deadline` (date, application deadline)
      - `eligibility` (text, requirements)
      - `link` (text, application link)
      - `is_active` (boolean, whether still accepting applications)
      - `created_at` (timestamp)
    
    - `chat_messages`
      - `id` (uuid, primary key)
      - `session_id` (text, anonymous session identifier)
      - `message` (text, user message)
      - `response` (text, bot response)
      - `language` (text, en or ur)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access (anonymous users)
    - Add policies for write access where needed
*/

CREATE TABLE IF NOT EXISTS careers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  title_urdu text NOT NULL,
  description text NOT NULL,
  description_urdu text NOT NULL,
  category text NOT NULL,
  duration_years integer NOT NULL DEFAULT 4,
  average_cost integer NOT NULL DEFAULT 0,
  salary_range_min integer NOT NULL DEFAULT 0,
  salary_range_max integer NOT NULL DEFAULT 0,
  job_demand text NOT NULL DEFAULT 'Medium',
  required_subjects text[] DEFAULT '{}',
  universities text[] DEFAULT '{}',
  entry_tests text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assessment_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  question_urdu text NOT NULL,
  type text NOT NULL,
  category text NOT NULL,
  options jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  answers jsonb NOT NULL DEFAULT '{}',
  results jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS scholarships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  title_urdu text NOT NULL,
  description text NOT NULL,
  description_urdu text NOT NULL,
  type text NOT NULL,
  country text NOT NULL DEFAULT 'Pakistan',
  deadline date,
  eligibility text NOT NULL,
  link text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  message text NOT NULL,
  response text NOT NULL,
  language text NOT NULL DEFAULT 'en',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE careers ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE scholarships ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read careers"
  ON careers FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can read assessment questions"
  ON assessment_questions FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can create assessments"
  ON user_assessments FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own assessments"
  ON user_assessments FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can read scholarships"
  ON scholarships FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can create chat messages"
  ON chat_messages FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can read own chat messages"
  ON chat_messages FOR SELECT
  TO anon
  USING (true);