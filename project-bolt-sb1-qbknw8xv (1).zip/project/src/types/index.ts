export interface Career {
  id: string;
  title: string;
  title_urdu: string;
  description: string;
  description_urdu: string;
  category: string;
  duration_years: number;
  average_cost: number;
  salary_range_min: number;
  salary_range_max: number;
  job_demand: string;
  required_subjects: string[];
  universities: string[];
  entry_tests: string[];
  created_at: string;
}

export interface AssessmentQuestion {
  id: string;
  question: string;
  question_urdu: string;
  type: string;
  category: string;
  options: {
    text: string;
    text_urdu: string;
    value: number;
  }[];
  created_at: string;
}

export interface AssessmentResult {
  career_id: string;
  career_title: string;
  match_percentage: number;
  category: string;
}

export interface Scholarship {
  id: string;
  title: string;
  title_urdu: string;
  description: string;
  description_urdu: string;
  type: string;
  country: string;
  deadline: string | null;
  eligibility: string;
  link: string | null;
  is_active: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  session_id: string;
  message: string;
  response: string;
  language: string;
  created_at: string;
}

export type PageView = 'home' | 'assessment' | 'careers' | 'comparison' | 'scholarships' | 'chatbot';
