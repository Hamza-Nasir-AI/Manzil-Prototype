import { useState, useEffect } from 'react';
import { ArrowLeft, CheckCircle, Brain } from 'lucide-react';
import { supabase, getSessionId } from '../lib/supabase';
import type { AssessmentQuestion, AssessmentResult } from '../types';

interface AssessmentPageProps {
  onBack: () => void;
}

const sampleQuestions: AssessmentQuestion[] = [
  {
    id: '1',
    question: 'I enjoy solving complex mathematical problems',
    question_urdu: 'مجھے پیچیدہ ریاضیاتی مسائل حل کرنا پسند ہے',
    type: 'interest',
    category: 'analytical',
    options: [
      { text: 'Strongly Agree', text_urdu: 'بالکل متفق', value: 5 },
      { text: 'Agree', text_urdu: 'متفق', value: 4 },
      { text: 'Neutral', text_urdu: 'غیر جانبدار', value: 3 },
      { text: 'Disagree', text_urdu: 'غیر متفق', value: 2 },
      { text: 'Strongly Disagree', text_urdu: 'بالکل غیر متفق', value: 1 }
    ],
    created_at: ''
  },
  {
    id: '2',
    question: 'I am interested in helping people with their health problems',
    question_urdu: 'مجھے لوگوں کی صحت کے مسائل میں مدد کرنے میں دلچسپی ہے',
    type: 'interest',
    category: 'social',
    options: [
      { text: 'Strongly Agree', text_urdu: 'بالکل متفق', value: 5 },
      { text: 'Agree', text_urdu: 'متفق', value: 4 },
      { text: 'Neutral', text_urdu: 'غیر جانبدار', value: 3 },
      { text: 'Disagree', text_urdu: 'غیر متفق', value: 2 },
      { text: 'Strongly Disagree', text_urdu: 'بالکل غیر متفق', value: 1 }
    ],
    created_at: ''
  },
  {
    id: '3',
    question: 'I prefer working with technology and computers',
    question_urdu: 'میں ٹیکنالوجی اور کمپیوٹرز کے ساتھ کام کرنا پسند کرتا ہوں',
    type: 'interest',
    category: 'technical',
    options: [
      { text: 'Strongly Agree', text_urdu: 'بالکل متفق', value: 5 },
      { text: 'Agree', text_urdu: 'متفق', value: 4 },
      { text: 'Neutral', text_urdu: 'غیر جانبدار', value: 3 },
      { text: 'Disagree', text_urdu: 'غیر متفق', value: 2 },
      { text: 'Strongly Disagree', text_urdu: 'بالکل غیر متفق', value: 1 }
    ],
    created_at: ''
  },
  {
    id: '4',
    question: 'I enjoy creative activities like art, design, or writing',
    question_urdu: 'مجھے تخلیقی سرگرمیاں جیسے آرٹ، ڈیزائن، یا لکھنا پسند ہے',
    type: 'interest',
    category: 'creative',
    options: [
      { text: 'Strongly Agree', text_urdu: 'بالکل متفق', value: 5 },
      { text: 'Agree', text_urdu: 'متفق', value: 4 },
      { text: 'Neutral', text_urdu: 'غیر جانبدار', value: 3 },
      { text: 'Disagree', text_urdu: 'غیر متفق', value: 2 },
      { text: 'Strongly Disagree', text_urdu: 'بالکل غیر متفق', value: 1 }
    ],
    created_at: ''
  },
  {
    id: '5',
    question: 'I am interested in business and entrepreneurship',
    question_urdu: 'مجھے کاروبار اور کاروباری مواقع میں دلچسپی ہے',
    type: 'interest',
    category: 'business',
    options: [
      { text: 'Strongly Agree', text_urdu: 'بالکل متفق', value: 5 },
      { text: 'Agree', text_urdu: 'متفق', value: 4 },
      { text: 'Neutral', text_urdu: 'غیر جانبدار', value: 3 },
      { text: 'Disagree', text_urdu: 'غیر متفق', value: 2 },
      { text: 'Strongly Disagree', text_urdu: 'بالکل غیر متفق', value: 1 }
    ],
    created_at: ''
  }
];

export default function AssessmentPage({ onBack }: AssessmentPageProps) {
  const [questions, setQuestions] = useState<AssessmentQuestion[]>(sampleQuestions);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<AssessmentResult[]>([]);
  const [loading, setLoading] = useState(false);

  const handleAnswer = (value: number) => {
    const newAnswers = { ...answers, [questions[currentQuestion].id]: value };
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      calculateResults(newAnswers);
    }
  };

  const calculateResults = async (finalAnswers: Record<string, number>) => {
    setLoading(true);

    const categoryScores: Record<string, number> = {};
    questions.forEach(q => {
      const score = finalAnswers[q.id] || 0;
      categoryScores[q.category] = (categoryScores[q.category] || 0) + score;
    });

    const careerMapping: Record<string, string[]> = {
      analytical: ['Software Engineering', 'Data Science', 'Mathematics'],
      social: ['Medicine', 'Psychology', 'Social Work'],
      technical: ['Computer Science', 'Electrical Engineering', 'Information Technology'],
      creative: ['Graphic Design', 'Architecture', 'Media Studies'],
      business: ['Business Administration', 'Marketing', 'Finance']
    };

    const calculatedResults: AssessmentResult[] = [];
    Object.entries(categoryScores).forEach(([category, score]) => {
      const careers = careerMapping[category] || [];
      const maxScore = questions.filter(q => q.category === category).length * 5;
      const percentage = Math.round((score / maxScore) * 100);

      careers.forEach(career => {
        calculatedResults.push({
          career_id: career.toLowerCase().replace(/\s+/g, '-'),
          career_title: career,
          match_percentage: percentage,
          category
        });
      });
    });

    calculatedResults.sort((a, b) => b.match_percentage - a.match_percentage);
    setResults(calculatedResults.slice(0, 5));

    try {
      await supabase.from('user_assessments').insert({
        session_id: getSessionId(),
        answers: finalAnswers,
        results: calculatedResults
      });
    } catch (error) {
      console.error('Error saving assessment:', error);
    }

    setLoading(false);
    setShowResults(true);
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Home
          </button>

          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
            <div className="text-center mb-12">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Your Career Match Results</h1>
              <p className="text-xl text-gray-600">Based on your personality and interests</p>
            </div>

            <div className="space-y-6">
              {results.map((result, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border-2 border-gray-100 hover:border-emerald-200 transition-all"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center text-white font-bold">
                        #{index + 1}
                      </div>
                      <h3 className="text-xl font-bold text-gray-900">{result.career_title}</h3>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                        {result.match_percentage}%
                      </p>
                      <p className="text-sm text-gray-500">Match</p>
                    </div>
                  </div>
                  <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-blue-600 rounded-full transition-all duration-1000"
                      style={{ width: `${result.match_percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <button
                onClick={() => {
                  setCurrentQuestion(0);
                  setAnswers({});
                  setShowResults(false);
                }}
                className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-xl transform hover:-translate-y-1 transition-all"
              >
                Take Test Again
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
      <div className="max-w-3xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Brain className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Career Assessment</h1>
              <p className="text-gray-600">Question {currentQuestion + 1} of {questions.length}</p>
            </div>
          </div>

          <div className="mb-8">
            <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-blue-600 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              {questions[currentQuestion].question}
            </h2>
            <p className="text-xl text-gray-600" dir="rtl">
              {questions[currentQuestion].question_urdu}
            </p>
          </div>

          <div className="space-y-4">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(option.value)}
                className="w-full bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 rounded-xl p-6 text-left hover:border-emerald-500 hover:shadow-lg transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors mb-1">
                      {option.text}
                    </p>
                    <p className="text-sm text-gray-600" dir="rtl">{option.text_urdu}</p>
                  </div>
                  <div className="w-8 h-8 rounded-full border-2 border-gray-300 group-hover:border-emerald-500 group-hover:bg-emerald-500 transition-all"></div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
