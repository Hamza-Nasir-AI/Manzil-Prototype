import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Bot, User, Sparkles } from 'lucide-react';
import { supabase, getSessionId } from '../lib/supabase';

interface ChatbotPageProps {
  onBack: () => void;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function ChatbotPage({ onBack }: ChatbotPageProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Assalam-o-Alaikum! I am Manzil AI Assistant. I can help you with career guidance, subject selection, university information, and scholarship opportunities. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const careerResponses: Record<string, string> = {
    'software engineering': 'Software Engineering is an excellent career choice in Pakistan! You will need Computer Science/ICS in intermediate. Top universities include NUST, FAST, LUMS, and COMSATS. Entry tests required are NAT, ECAT, or NUST Entry Test. Starting salary ranges from 50,000 to 100,000 PKR per month with high job demand.',
    'medicine': 'Medicine (MBBS) is a highly respected career in Pakistan. You need Pre-Medical (Biology, Chemistry, Physics) in FSc. Top medical colleges include Aga Khan University, King Edward Medical College, Dow Medical College. You must pass MDCAT. The degree takes 5 years plus 1 year house job. Starting salary is around 80,000-120,000 PKR.',
    'business': 'Business Administration (BBA/MBA) opens doors to corporate leadership. You can take ICS, ICom, or Arts in intermediate. Top business schools include IBA Karachi, LUMS, NUST Business School. Entry tests include IBA Test, LUMS SAT, or NTS. Job opportunities in banking, marketing, finance, and entrepreneurship are abundant.',
    'engineering': 'Engineering has many fields: Computer, Electrical, Civil, Mechanical, etc. You need Pre-Engineering (Maths, Physics, Chemistry) in FSc. Top engineering universities include NUST, UET, GIKI, NED. You need to pass ECAT or NUST Entry Test. Starting salary ranges from 40,000 to 80,000 PKR depending on the field.',
    'scholarship': 'There are many scholarships available for Pakistani students:\n\nNational: PEEF, HEC, Ehsaas, Punjab Educational Endowment Fund\n\nInternational: Turkiye Burslari (Turkey), Chevening (UK), Fulbright (USA), Chinese Government Scholarship, King Fahd University (Saudi Arabia)\n\nMost scholarships cover tuition, accommodation, and living expenses. Apply early and maintain good grades!',
    'default': 'I can help you with information about careers, universities, subjects, scholarships, and admission guidance. Please ask me about:\n\n- Specific careers (Software Engineering, Medicine, Business, etc.)\n- Subject selection after Matric\n- University and entry test information\n- Scholarship opportunities\n- Career paths and salary expectations\n\nWhat would you like to know?'
  };

  const getResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    if (lowerMessage.includes('software') || lowerMessage.includes('programming') || lowerMessage.includes('computer science')) {
      return careerResponses['software engineering'];
    }
    if (lowerMessage.includes('medicine') || lowerMessage.includes('doctor') || lowerMessage.includes('mbbs')) {
      return careerResponses['medicine'];
    }
    if (lowerMessage.includes('business') || lowerMessage.includes('bba') || lowerMessage.includes('mba')) {
      return careerResponses['business'];
    }
    if (lowerMessage.includes('engineering') || lowerMessage.includes('engineer')) {
      return careerResponses['engineering'];
    }
    if (lowerMessage.includes('scholarship') || lowerMessage.includes('financial aid') || lowerMessage.includes('funding')) {
      return careerResponses['scholarship'];
    }
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('salam')) {
      return 'Wa-Alaikum-Assalam! How can I assist you with your career planning today?';
    }
    if (lowerMessage.includes('matric') || lowerMessage.includes('subject') || lowerMessage.includes('intermediate')) {
      return 'After Matric, you can choose from several groups:\n\n1. Pre-Medical (Biology, Chemistry, Physics) - for Medicine, Pharmacy, etc.\n2. Pre-Engineering (Maths, Physics, Chemistry) - for Engineering fields\n3. Computer Science (Maths, Physics, Computer) - for IT and Software\n4. Commerce (Accounting, Economics, Business) - for Business careers\n5. Arts (various subjects) - for Social Sciences, Law, etc.\n\nWhat are your interests?';
    }

    return careerResponses['default'];
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    setTimeout(() => {
      const aiResponse: Message = {
        role: 'assistant',
        content: getResponse(input),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      setLoading(false);

      try {
        supabase.from('chat_messages').insert({
          session_id: getSessionId(),
          message: input,
          response: aiResponse.content,
          language: 'en'
        });
      } catch (error) {
        console.error('Error saving chat:', error);
      }
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
      <div className="max-w-4xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden" style={{ height: 'calc(100vh - 200px)' }}>
          <div className="bg-gradient-to-r from-emerald-500 to-blue-600 p-6 text-white">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center">
                <Sparkles className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">AI Career Consultant</h1>
                <p className="text-emerald-50">Free 24/7 Career Guidance in Urdu & English</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col h-full" style={{ height: 'calc(100% - 100px)' }}>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.role === 'assistant' && (
                    <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                  )}
                  <div
                    className={`max-w-[70%] rounded-2xl p-4 ${
                      message.role === 'user'
                        ? 'bg-gradient-to-br from-emerald-500 to-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="whitespace-pre-line leading-relaxed">{message.content}</p>
                    <p className={`text-xs mt-2 ${
                      message.role === 'user' ? 'text-emerald-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {message.role === 'user' && (
                    <div className="w-10 h-10 bg-gradient-to-br from-gray-200 to-gray-300 rounded-xl flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-gray-700" />
                    </div>
                  )}
                </div>
              ))}
              {loading && (
                <div className="flex gap-3 justify-start">
                  <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="bg-gray-100 rounded-2xl p-4">
                    <div className="flex gap-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="border-t border-gray-200 p-6">
              <div className="flex gap-3">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about careers..."
                  className="flex-1 px-6 py-4 bg-gray-50 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 transition-colors"
                  disabled={loading}
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || loading}
                  className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-xl transform hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
