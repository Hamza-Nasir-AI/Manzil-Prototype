import { useState } from 'react';
import { ArrowLeft, Plus, X, Clock, DollarSign, TrendingUp, BookOpen } from 'lucide-react';
import type { Career } from '../types';

interface ComparisonPageProps {
  onBack: () => void;
  onOpenCareerLibrary: () => void;
}

const sampleCareers: Career[] = [
  {
    id: '1',
    title: 'Software Engineering',
    title_urdu: 'سافٹ ویئر انجینئرنگ',
    description: 'Design, develop, and maintain software applications and systems.',
    description_urdu: 'سافٹ ویئر ایپلیکیشنز اور سسٹمز کو ڈیزائن، تیار اور برقرار رکھیں۔',
    category: 'Technology',
    duration_years: 4,
    average_cost: 400000,
    salary_range_min: 50000,
    salary_range_max: 300000,
    job_demand: 'High',
    required_subjects: ['Mathematics', 'Computer Science', 'Physics'],
    universities: ['NUST', 'FAST', 'LUMS', 'COMSATS'],
    entry_tests: ['NAT', 'ECAT', 'NUST Entry Test'],
    created_at: ''
  },
  {
    id: '2',
    title: 'Medicine (MBBS)',
    title_urdu: 'طب (ایم بی بی ایس)',
    description: 'Become a medical doctor and help diagnose, treat, and prevent illnesses.',
    description_urdu: 'میڈیکل ڈاکٹر بنیں اور بیماریوں کی تشخیص، علاج اور روک تھام میں مدد کریں۔',
    category: 'Medical',
    duration_years: 5,
    average_cost: 2000000,
    salary_range_min: 80000,
    salary_range_max: 500000,
    job_demand: 'High',
    required_subjects: ['Biology', 'Chemistry', 'Physics'],
    universities: ['Aga Khan', 'Dow Medical', 'KEMU'],
    entry_tests: ['MDCAT', 'AKU Test'],
    created_at: ''
  },
  {
    id: '3',
    title: 'Business Administration',
    title_urdu: 'بزنس ایڈمنسٹریشن',
    description: 'Learn management, finance, marketing, and entrepreneurship skills.',
    description_urdu: 'انتظام، مالیات، مارکیٹنگ اور کاروباری مہارتیں سیکھیں۔',
    category: 'Business',
    duration_years: 4,
    average_cost: 600000,
    salary_range_min: 40000,
    salary_range_max: 250000,
    job_demand: 'High',
    required_subjects: ['Mathematics', 'Economics'],
    universities: ['IBA', 'LUMS', 'NUST Business School'],
    entry_tests: ['IBA Test', 'LUMS SAT', 'NTS'],
    created_at: ''
  }
];

export default function ComparisonPage({ onBack, onOpenCareerLibrary }: ComparisonPageProps) {
  const [selectedCareers, setSelectedCareers] = useState<Career[]>([]);
  const [showCareerSelector, setShowCareerSelector] = useState(false);

  const addCareer = (career: Career) => {
    if (selectedCareers.length < 3 && !selectedCareers.find(c => c.id === career.id)) {
      setSelectedCareers([...selectedCareers, career]);
      setShowCareerSelector(false);
    }
  };

  const removeCareer = (id: string) => {
    setSelectedCareers(selectedCareers.filter(c => c.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Compare Careers</h1>
            <p className="text-xl text-gray-600">
              Compare up to 3 careers side by side to make an informed decision
            </p>
          </div>

          {selectedCareers.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Plus className="w-10 h-10 text-emerald-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Start Comparing</h2>
              <p className="text-gray-600 mb-8">Select careers from the list below to begin comparison</p>
              <button
                onClick={() => setShowCareerSelector(true)}
                className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-xl transform hover:-translate-y-1 transition-all"
              >
                Select Careers
              </button>
            </div>
          ) : (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {selectedCareers.map(career => (
                  <div key={career.id} className="relative">
                    <button
                      onClick={() => removeCareer(career.id)}
                      className="absolute -top-3 -right-3 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors z-10"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border-2 border-emerald-200 h-full">
                      <div className="text-center mb-4">
                        <h3 className="text-xl font-bold text-gray-900 mb-1">{career.title}</h3>
                        <p className="text-sm text-gray-600" dir="rtl">{career.title_urdu}</p>
                      </div>
                      <div className="space-y-3">
                        <div className="bg-white rounded-xl p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <Clock className="w-4 h-4 text-emerald-600" />
                            <p className="text-sm text-gray-600">Duration</p>
                          </div>
                          <p className="font-bold text-gray-900">{career.duration_years} Years</p>
                        </div>
                        <div className="bg-white rounded-xl p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <DollarSign className="w-4 h-4 text-blue-600" />
                            <p className="text-sm text-gray-600">Avg. Cost</p>
                          </div>
                          <p className="font-bold text-gray-900">
                            {(career.average_cost / 100000).toFixed(1)}L PKR
                          </p>
                        </div>
                        <div className="bg-white rounded-xl p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <TrendingUp className="w-4 h-4 text-emerald-600" />
                            <p className="text-sm text-gray-600">Job Demand</p>
                          </div>
                          <p className={`font-bold ${
                            career.job_demand === 'High' ? 'text-emerald-600' : 'text-blue-600'
                          }`}>
                            {career.job_demand}
                          </p>
                        </div>
                        <div className="bg-white rounded-xl p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <DollarSign className="w-4 h-4 text-blue-600" />
                            <p className="text-sm text-gray-600">Salary Range</p>
                          </div>
                          <p className="font-bold text-gray-900">
                            {career.salary_range_min / 1000}K - {career.salary_range_max / 1000}K
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {selectedCareers.length < 3 && (
                  <button
                    onClick={() => setShowCareerSelector(true)}
                    className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border-2 border-dashed border-gray-300 hover:border-emerald-500 transition-all flex flex-col items-center justify-center min-h-[400px]"
                  >
                    <Plus className="w-12 h-12 text-gray-400 mb-4" />
                    <p className="font-semibold text-gray-600">Add Career</p>
                  </button>
                )}
              </div>

              <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Detailed Comparison</h3>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-emerald-600" />
                      Required Subjects
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      {selectedCareers.map(career => (
                        <div key={career.id} className="bg-white rounded-xl p-4">
                          <p className="font-semibold text-gray-900 mb-2">{career.title}</p>
                          <div className="flex flex-wrap gap-2">
                            {career.required_subjects.map((subject, idx) => (
                              <span key={idx} className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded">
                                {subject}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-900 mb-3">Top Universities</h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      {selectedCareers.map(career => (
                        <div key={career.id} className="bg-white rounded-xl p-4">
                          <p className="font-semibold text-gray-900 mb-2">{career.title}</p>
                          <ul className="space-y-1 text-sm text-gray-600">
                            {career.universities.slice(0, 3).map((uni, idx) => (
                              <li key={idx}>• {uni}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-900 mb-3">Entry Tests</h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      {selectedCareers.map(career => (
                        <div key={career.id} className="bg-white rounded-xl p-4">
                          <p className="font-semibold text-gray-900 mb-2">{career.title}</p>
                          <div className="flex flex-wrap gap-2">
                            {career.entry_tests.map((test, idx) => (
                              <span key={idx} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                                {test}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {showCareerSelector && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-6">
              <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[80vh] overflow-y-auto p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Select a Career</h2>
                  <button
                    onClick={() => setShowCareerSelector(false)}
                    className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {sampleCareers
                    .filter(career => !selectedCareers.find(c => c.id === career.id))
                    .map(career => (
                      <button
                        key={career.id}
                        onClick={() => addCareer(career)}
                        className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 border-2 border-gray-100 hover:border-emerald-500 transition-all text-left"
                      >
                        <h3 className="text-lg font-bold text-gray-900 mb-1">{career.title}</h3>
                        <p className="text-sm text-gray-600 mb-3" dir="rtl">{career.title_urdu}</p>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-gray-600">{career.duration_years} years</span>
                          <span className="text-emerald-600 font-semibold">{career.job_demand} demand</span>
                        </div>
                      </button>
                    ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
