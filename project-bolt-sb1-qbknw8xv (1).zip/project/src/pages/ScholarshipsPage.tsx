import { useState, useEffect } from 'react';
import { ArrowLeft, Search, Award, Calendar, MapPin, ExternalLink, Globe } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Scholarship } from '../types';

interface ScholarshipsPageProps {
  onBack: () => void;
}

const sampleScholarships: Scholarship[] = [
  {
    id: '1',
    title: 'PEEF Scholarship',
    title_urdu: 'پی ای ای ایف اسکالرشپ',
    description: 'Punjab Educational Endowment Fund provides scholarships to talented students from low-income families across Punjab for undergraduate studies.',
    description_urdu: 'پنجاب ایجوکیشنل اینڈومنٹ فنڈ کم آمدنی والے خاندانوں کے ذہین طلباء کو انڈر گریجویٹ تعلیم کے لیے اسکالرشپ فراہم کرتا ہے۔',
    type: 'National',
    country: 'Pakistan',
    deadline: '2025-12-31',
    eligibility: 'Punjab domicile, Family income less than 300,000 PKR annually, Minimum 60% marks in previous degree',
    link: 'https://peef.org.pk',
    is_active: true,
    created_at: ''
  },
  {
    id: '2',
    title: 'Turkiye Burslari',
    title_urdu: 'ترکی برسلری',
    description: 'Fully funded scholarship by Turkish Government for undergraduate, masters, and PhD programs. Covers tuition, accommodation, health insurance, and monthly stipend.',
    description_urdu: 'ترکی حکومت کی جانب سے انڈر گریجویٹ، ماسٹرز اور پی ایچ ڈی پروگراموں کے لیے مکمل فنڈڈ اسکالرشپ۔',
    type: 'International',
    country: 'Turkey',
    deadline: '2025-02-20',
    eligibility: 'Under 21 for bachelors, Under 30 for masters, Under 35 for PhD, Minimum 70% marks',
    link: 'https://turkiyeburslari.gov.tr',
    is_active: true,
    created_at: ''
  },
  {
    id: '3',
    title: 'HEC Need Based Scholarship',
    title_urdu: 'ایچ ای سی نیڈ بیسڈ اسکالرشپ',
    description: 'Higher Education Commission provides need-based scholarships to deserving students pursuing undergraduate studies in HEC-recognized universities.',
    description_urdu: 'ہائیر ایجوکیشن کمیشن مستحق طلباء کو ایچ ای سی سے تسلیم شدہ یونیورسٹیوں میں انڈر گریجویٹ تعلیم حاصل کرنے کے لیے نیڈ بیسڈ اسکالرشپ فراہم کرتا ہے۔',
    type: 'National',
    country: 'Pakistan',
    deadline: '2025-10-15',
    eligibility: 'Pakistani national, Family income less than 45,000 PKR monthly, Enrolled in HEC recognized university',
    link: 'https://hec.gov.pk',
    is_active: true,
    created_at: ''
  },
  {
    id: '4',
    title: 'Chinese Government Scholarship',
    title_urdu: 'چینی حکومت کی اسکالرشپ',
    description: 'Full scholarship for international students to study in Chinese universities. Covers tuition, accommodation, medical insurance, and monthly living allowance.',
    description_urdu: 'بین الاقوامی طلباء کے لیے چینی یونیورسٹیوں میں تعلیم حاصل کرنے کے لیے مکمل اسکالرشپ۔',
    type: 'International',
    country: 'China',
    deadline: '2025-04-30',
    eligibility: 'Under 25 for bachelors, Under 35 for masters, Under 40 for PhD, Good academic record',
    link: 'https://www.campuschina.org',
    is_active: true,
    created_at: ''
  },
  {
    id: '5',
    title: 'Ehsaas Undergraduate Scholarship',
    title_urdu: 'احساس انڈر گریجویٹ اسکالرشپ',
    description: 'Government of Pakistan initiative to provide financial assistance to talented students from underprivileged backgrounds for higher education.',
    description_urdu: 'حکومت پاکستان کا اقدام ناقص پس منظر سے تعلق رکھنے والے ذہین طلباء کو اعلیٰ تعلیم کے لیے مالی مدد فراہم کرنے کے لیے۔',
    type: 'National',
    country: 'Pakistan',
    deadline: '2025-11-30',
    eligibility: 'Family monthly income less than 45,000 PKR, Minimum 60% marks, Age under 22 years',
    link: 'https://ehsaas.gov.pk',
    is_active: true,
    created_at: ''
  },
  {
    id: '6',
    title: 'King Fahd University Scholarship',
    title_urdu: 'کنگ فہد یونیورسٹی اسکالرشپ',
    description: 'Full scholarship to study at King Fahd University of Petroleum and Minerals in Saudi Arabia. Covers all expenses including flights.',
    description_urdu: 'سعودی عرب میں کنگ فہد یونیورسٹی آف پٹرولیم اینڈ منرلز میں تعلیم حاصل کرنے کے لیے مکمل اسکالرشپ۔',
    type: 'International',
    country: 'Saudi Arabia',
    deadline: '2025-03-15',
    eligibility: 'Excellent academic record, Strong English proficiency, Under 25 for bachelors',
    link: 'https://www.kfupm.edu.sa',
    is_active: true,
    created_at: ''
  }
];

export default function ScholarshipsPage({ onBack }: ScholarshipsPageProps) {
  const [scholarships, setScholarships] = useState<Scholarship[]>(sampleScholarships);
  const [filteredScholarships, setFilteredScholarships] = useState<Scholarship[]>(sampleScholarships);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedScholarship, setSelectedScholarship] = useState<Scholarship | null>(null);

  const types = ['All', 'National', 'International'];

  useEffect(() => {
    let filtered = scholarships;

    if (selectedType !== 'All') {
      filtered = filtered.filter(s => s.type === selectedType);
    }

    if (searchQuery) {
      filtered = filtered.filter(s =>
        s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.title_urdu.includes(searchQuery) ||
        s.country.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredScholarships(filtered);
  }, [searchQuery, selectedType, scholarships]);

  if (selectedScholarship) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => setSelectedScholarship(null)}
            className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Scholarships
          </button>

          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                  selectedScholarship.type === 'International'
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {selectedScholarship.type}
                </span>
                <div className="flex items-center gap-2 text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{selectedScholarship.country}</span>
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">{selectedScholarship.title}</h1>
              <p className="text-2xl text-gray-600" dir="rtl">{selectedScholarship.title_urdu}</p>
            </div>

            {selectedScholarship.deadline && (
              <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl p-6 mb-8">
                <div className="flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-red-600" />
                  <div>
                    <p className="text-sm text-gray-600">Application Deadline</p>
                    <p className="text-xl font-bold text-gray-900">
                      {new Date(selectedScholarship.deadline).toLocaleDateString('en-GB', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Scholarship</h2>
                <p className="text-gray-700 leading-relaxed mb-4">{selectedScholarship.description}</p>
                <p className="text-gray-600 leading-relaxed" dir="rtl">{selectedScholarship.description_urdu}</p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Eligibility Criteria</h3>
                <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-2xl p-6">
                  <ul className="space-y-2">
                    {selectedScholarship.eligibility.split(',').map((criterion, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="text-white text-xs font-bold">{index + 1}</span>
                        </div>
                        <p className="text-gray-700">{criterion.trim()}</p>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {selectedScholarship.link && (
                <div>
                  <a
                    href={selectedScholarship.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-xl transform hover:-translate-y-1 transition-all"
                  >
                    <ExternalLink className="w-5 h-5" />
                    Visit Official Website
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Scholarships & Financial Aid</h1>
            <p className="text-xl text-gray-600">
              Discover funding opportunities for your education in Pakistan and abroad
            </p>
          </div>

          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search scholarships..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-8">
            {types.map(type => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  selectedType === type
                    ? 'bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {filteredScholarships.map(scholarship => (
              <button
                key={scholarship.id}
                onClick={() => setSelectedScholarship(scholarship)}
                className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border-2 border-gray-100 hover:border-emerald-200 hover:shadow-xl transition-all text-left"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      scholarship.type === 'International'
                        ? 'bg-gradient-to-br from-blue-500 to-blue-600'
                        : 'bg-gradient-to-br from-emerald-500 to-emerald-600'
                    }`}>
                      {scholarship.type === 'International' ? (
                        <Globe className="w-6 h-6 text-white" />
                      ) : (
                        <Award className="w-6 h-6 text-white" />
                      )}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      scholarship.type === 'International'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}>
                      {scholarship.type}
                    </span>
                  </div>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-1">{scholarship.title}</h3>
                <p className="text-sm text-gray-600 mb-4" dir="rtl">{scholarship.title_urdu}</p>

                <div className="flex items-center gap-4 mb-4 text-sm">
                  <div className="flex items-center gap-1 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>{scholarship.country}</span>
                  </div>
                  {scholarship.deadline && (
                    <div className="flex items-center gap-1 text-red-600">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {new Date(scholarship.deadline).toLocaleDateString('en-GB', {
                          day: 'numeric',
                          month: 'short'
                        })}
                      </span>
                    </div>
                  )}
                </div>

                <p className="text-gray-600 text-sm line-clamp-2">{scholarship.description}</p>
              </button>
            ))}
          </div>

          {filteredScholarships.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No scholarships found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
