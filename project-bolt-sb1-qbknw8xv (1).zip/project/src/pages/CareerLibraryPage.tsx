import { useState, useEffect } from 'react';
import { ArrowLeft, Search, BookOpen, TrendingUp, DollarSign, Clock, Building, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Career } from '../types';

interface CareerLibraryPageProps {
  onBack: () => void;
  onSelectCareer?: (career: Career) => void;
}

const sampleCareers: Career[] = [
  {
    id: '1',
    title: 'Software Engineering',
    title_urdu: 'سافٹ ویئر انجینئرنگ',
    description: 'Design, develop, and maintain software applications and systems. Software engineers work on everything from mobile apps to large-scale enterprise systems.',
    description_urdu: 'سافٹ ویئر ایپلیکیشنز اور سسٹمز کو ڈیزائن، تیار اور برقرار رکھیں۔',
    category: 'Technology',
    duration_years: 4,
    average_cost: 400000,
    salary_range_min: 50000,
    salary_range_max: 300000,
    job_demand: 'High',
    required_subjects: ['Mathematics', 'Computer Science', 'Physics'],
    universities: ['NUST', 'FAST', 'LUMS', 'COMSATS', 'UET'],
    entry_tests: ['NAT', 'ECAT', 'NUST Entry Test'],
    created_at: ''
  },
  {
    id: '2',
    title: 'Medicine (MBBS)',
    title_urdu: 'طب (ایم بی بی ایس)',
    description: 'Become a medical doctor and help diagnose, treat, and prevent illnesses. MBBS is a 5-year degree followed by 1 year of house job.',
    description_urdu: 'میڈیکل ڈاکٹر بنیں اور بیماریوں کی تشخیص، علاج اور روک تھام میں مدد کریں۔',
    category: 'Medical',
    duration_years: 5,
    average_cost: 2000000,
    salary_range_min: 80000,
    salary_range_max: 500000,
    job_demand: 'High',
    required_subjects: ['Biology', 'Chemistry', 'Physics'],
    universities: ['Aga Khan University', 'Dow Medical College', 'King Edward Medical University', 'Allama Iqbal Medical College'],
    entry_tests: ['MDCAT', 'AKU Test'],
    created_at: ''
  },
  {
    id: '3',
    title: 'Business Administration',
    title_urdu: 'بزنس ایڈمنسٹریشن',
    description: 'Learn management, finance, marketing, and entrepreneurship skills. BBA prepares you for corporate leadership and business ventures.',
    description_urdu: 'انتظام، مالیات، مارکیٹنگ اور کاروباری مہارتیں سیکھیں۔',
    category: 'Business',
    duration_years: 4,
    average_cost: 600000,
    salary_range_min: 40000,
    salary_range_max: 250000,
    job_demand: 'High',
    required_subjects: ['Mathematics', 'Economics', 'Business Studies'],
    universities: ['IBA Karachi', 'LUMS', 'NUST Business School', 'CBM'],
    entry_tests: ['IBA Test', 'LUMS SAT', 'NTS'],
    created_at: ''
  },
  {
    id: '4',
    title: 'Civil Engineering',
    title_urdu: 'سول انجینئرنگ',
    description: 'Design and oversee construction of infrastructure projects like buildings, roads, bridges, and water systems.',
    description_urdu: 'عمارتوں، سڑکوں، پلوں اور پانی کے نظام جیسے بنیادی ڈھانچے کے منصوبوں کی تعمیر کی ڈیزائن اور نگرانی کریں۔',
    category: 'Engineering',
    duration_years: 4,
    average_cost: 500000,
    salary_range_min: 45000,
    salary_range_max: 200000,
    job_demand: 'Medium',
    required_subjects: ['Mathematics', 'Physics', 'Chemistry'],
    universities: ['NUST', 'UET', 'NED University', 'GIKI'],
    entry_tests: ['ECAT', 'NUST Entry Test'],
    created_at: ''
  },
  {
    id: '5',
    title: 'Graphic Design',
    title_urdu: 'گرافک ڈیزائن',
    description: 'Create visual content for brands, marketing campaigns, websites, and digital media using design software and creativity.',
    description_urdu: 'ڈیزائن سافٹ ویئر اور تخلیقی صلاحیتوں کا استعمال کرتے ہوئے برانڈز، مارکیٹنگ مہمات، ویب سائٹس اور ڈیجیٹل میڈیا کے لیے بصری مواد تخلیق کریں۔',
    category: 'Creative Arts',
    duration_years: 4,
    average_cost: 400000,
    salary_range_min: 30000,
    salary_range_max: 150000,
    job_demand: 'Medium',
    required_subjects: ['Fine Arts', 'Computer Science', 'English'],
    universities: ['NCA', 'Indus Valley School', 'IQRA University', 'Beaconhouse'],
    entry_tests: ['Portfolio Review', 'Aptitude Test'],
    created_at: ''
  },
  {
    id: '6',
    title: 'Data Science',
    title_urdu: 'ڈیٹا سائنس',
    description: 'Analyze large datasets to extract insights, build predictive models, and help organizations make data-driven decisions.',
    description_urdu: 'بصیرت نکالنے، پیشن گوئی کے ماڈل بنانے اور تنظیموں کو ڈیٹا پر مبنی فیصلے کرنے میں مدد کرنے کے لیے بڑے ڈیٹا سیٹس کا تجزیہ کریں۔',
    category: 'Technology',
    duration_years: 4,
    average_cost: 450000,
    salary_range_min: 60000,
    salary_range_max: 350000,
    job_demand: 'High',
    required_subjects: ['Mathematics', 'Statistics', 'Computer Science'],
    universities: ['NUST', 'FAST', 'LUMS', 'IBA'],
    entry_tests: ['NAT', 'NUST Entry Test', 'IBA Test'],
    created_at: ''
  }
];

export default function CareerLibraryPage({ onBack, onSelectCareer }: CareerLibraryPageProps) {
  const [careers, setCareers] = useState<Career[]>(sampleCareers);
  const [filteredCareers, setFilteredCareers] = useState<Career[]>(sampleCareers);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCareer, setSelectedCareer] = useState<Career | null>(null);

  const categories = ['All', 'Technology', 'Medical', 'Business', 'Engineering', 'Creative Arts'];

  useEffect(() => {
    let filtered = careers;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(career => career.category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(career =>
        career.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        career.title_urdu.includes(searchQuery) ||
        career.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredCareers(filtered);
  }, [searchQuery, selectedCategory, careers]);

  if (selectedCareer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
        <div className="max-w-5xl mx-auto">
          <button
            onClick={() => setSelectedCareer(null)}
            className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Library
          </button>

          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
            <div className="mb-8">
              <div className="inline-block bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold mb-4">
                {selectedCareer.category}
              </div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">{selectedCareer.title}</h1>
              <p className="text-2xl text-gray-600" dir="rtl">{selectedCareer.title_urdu}</p>
            </div>

            <div className="grid md:grid-cols-4 gap-4 mb-8">
              <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl p-4">
                <Clock className="w-6 h-6 text-emerald-600 mb-2" />
                <p className="text-sm text-gray-600">Duration</p>
                <p className="text-xl font-bold text-gray-900">{selectedCareer.duration_years} Years</p>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4">
                <DollarSign className="w-6 h-6 text-blue-600 mb-2" />
                <p className="text-sm text-gray-600">Avg. Cost</p>
                <p className="text-xl font-bold text-gray-900">
                  {(selectedCareer.average_cost / 100000).toFixed(1)}L PKR
                </p>
              </div>
              <div className="bg-gradient-to-br from-emerald-50 to-blue-100 rounded-xl p-4">
                <TrendingUp className="w-6 h-6 text-emerald-600 mb-2" />
                <p className="text-sm text-gray-600">Job Demand</p>
                <p className="text-xl font-bold text-gray-900">{selectedCareer.job_demand}</p>
              </div>
              <div className="bg-gradient-to-br from-blue-50 to-emerald-100 rounded-xl p-4">
                <DollarSign className="w-6 h-6 text-blue-600 mb-2" />
                <p className="text-sm text-gray-600">Salary Range</p>
                <p className="text-lg font-bold text-gray-900">
                  {selectedCareer.salary_range_min / 1000}K-{selectedCareer.salary_range_max / 1000}K
                </p>
              </div>
            </div>

            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Career</h2>
                <p className="text-gray-700 leading-relaxed mb-4">{selectedCareer.description}</p>
                <p className="text-gray-600 leading-relaxed" dir="rtl">{selectedCareer.description_urdu}</p>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  Required Subjects
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedCareer.required_subjects.map((subject, index) => (
                    <span
                      key={index}
                      className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-lg font-medium"
                    >
                      {subject}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Building className="w-5 h-5 text-blue-600" />
                  Top Universities
                </h3>
                <div className="grid md:grid-cols-2 gap-3">
                  {selectedCareer.universities.map((university, index) => (
                    <div
                      key={index}
                      className="bg-gray-50 rounded-xl p-4 border-2 border-gray-100 hover:border-blue-300 transition-colors"
                    >
                      <p className="font-semibold text-gray-900">{university}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-600" />
                  Entry Tests
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedCareer.entry_tests.map((test, index) => (
                    <span
                      key={index}
                      className="bg-blue-100 text-blue-700 px-4 py-2 rounded-lg font-medium"
                    >
                      {test}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {onSelectCareer && (
              <div className="mt-8 pt-8 border-t border-gray-200">
                <button
                  onClick={() => onSelectCareer(selectedCareer)}
                  className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-xl transform hover:-translate-y-1 transition-all"
                >
                  Add to Comparison
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Career Library</h1>
            <p className="text-xl text-gray-600">
              Explore 200+ career paths with detailed information
            </p>
          </div>

          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search careers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-8">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-xl font-semibold transition-all ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCareers.map(career => (
              <button
                key={career.id}
                onClick={() => setSelectedCareer(career)}
                className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border-2 border-gray-100 hover:border-emerald-200 hover:shadow-xl transition-all text-left"
              >
                <div className="mb-4">
                  <span className="inline-block bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-semibold mb-3">
                    {career.category}
                  </span>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{career.title}</h3>
                  <p className="text-sm text-gray-600" dir="rtl">{career.title_urdu}</p>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Duration:</span>
                    <span className="font-semibold text-gray-900">{career.duration_years} years</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Job Demand:</span>
                    <span className={`font-semibold ${
                      career.job_demand === 'High' ? 'text-emerald-600' : 'text-blue-600'
                    }`}>
                      {career.job_demand}
                    </span>
                  </div>
                </div>

                <p className="text-gray-600 text-sm line-clamp-3">{career.description}</p>
              </button>
            ))}
          </div>

          {filteredCareers.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No careers found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
