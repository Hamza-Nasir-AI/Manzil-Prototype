import { CheckCircle, Smartphone, Globe, Shield } from 'lucide-react';

export default function CTA() {
  return (
    <div className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 py-24 px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-blue-500/10"></div>
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/20 rounded-full filter blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/20 rounded-full filter blur-3xl"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-block bg-emerald-500/20 text-emerald-300 px-4 py-2 rounded-full text-sm font-semibold">
              Coming Soon
            </div>

            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Download Manzil App &<br />
              <span className="bg-gradient-to-r from-emerald-400 to-blue-400 bg-clip-text text-transparent">
                Start Your Journey
              </span>
            </h2>

            <p className="text-xl text-gray-300 leading-relaxed">
              Take control of your future with Pakistan's most comprehensive career guidance platform. Available soon on Android and iOS.
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <p className="text-gray-200">100% Free to use, no hidden charges</p>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <p className="text-gray-200">Full Urdu and English support</p>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <p className="text-gray-200">Offline access to saved content</p>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-400" />
                <p className="text-gray-200">Regular scholarship and admission alerts</p>
              </div>
            </div>

            <div className="pt-4">
              <p className="text-gray-400 mb-4">Get notified when we launch:</p>
              <div className="flex gap-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:border-emerald-400 transition-colors"
                />
                <button className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-2xl transform hover:-translate-y-1 transition-all">
                  Notify Me
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center">
                  <Smartphone className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Mobile-First Design</h3>
                  <p className="text-gray-400">Optimized for Android & iOS</p>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Access Manzil anytime, anywhere from your smartphone. Designed specifically for mobile users with a smooth, intuitive interface.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                  <Globe className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Local & Global Options</h3>
                  <p className="text-gray-400">Pakistan and International</p>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Explore career opportunities in Pakistan and discover international scholarships to study abroad in top universities worldwide.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-emerald-600 to-blue-600 rounded-xl flex items-center justify-center">
                  <Shield className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Safe & Private</h3>
                  <p className="text-gray-400">Your data is secure</p>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                We respect your privacy. Your personal information and test results are encrypted and never shared with third parties.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
