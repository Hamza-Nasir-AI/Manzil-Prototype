import { UserCheck, Target, BookCheck, Rocket } from 'lucide-react';

const steps = [
  {
    icon: UserCheck,
    step: '01',
    title: 'Take the Assessment',
    titleUrdu: 'تشخیص کریں',
    description: 'Complete our 5-minute personality and interest test to discover what careers align with your strengths and passions.'
  },
  {
    icon: Target,
    step: '02',
    title: 'Get Personalized Results',
    titleUrdu: 'ذاتی نتائج حاصل کریں',
    description: 'Receive detailed career recommendations with fit percentages, showing the best paths matched to your profile.'
  },
  {
    icon: BookCheck,
    step: '03',
    title: 'Explore Career Paths',
    titleUrdu: 'کیریئر راستے دریافت کریں',
    description: 'Dive deep into career details including required subjects, universities, entry tests, salaries, and real job prospects.'
  },
  {
    icon: Rocket,
    step: '04',
    title: 'Take Action',
    titleUrdu: 'عمل کریں',
    description: 'Apply for scholarships, prepare for admission tests, and get expert guidance to turn your career dreams into reality.'
  }
];

export default function HowItWorks() {
  return (
    <div id="how-it-works" className="bg-gradient-to-br from-gray-50 to-white py-24 px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-16">
          <div className="inline-block bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold">
            How It Works
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900">
            Your Journey to <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">Career Clarity</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Four simple steps to discover your ideal career path and plan your educational journey
          </p>
        </div>

        <div className="relative">
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-emerald-200 via-blue-200 to-emerald-200 -translate-y-1/2 -z-10"></div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-shadow border-2 border-gray-100 hover:border-emerald-200">
                  <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                    {step.step}
                  </div>

                  <div className="w-16 h-16 bg-gradient-to-br from-emerald-100 to-blue-100 rounded-2xl flex items-center justify-center mb-6">
                    <step.icon className="w-8 h-8 text-emerald-600" />
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                  <p className="text-sm text-gray-500 mb-4" dir="rtl">{step.titleUrdu}</p>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <button className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-10 py-4 rounded-xl font-bold text-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all">
            Start Your Journey Today
          </button>
          <p className="text-gray-600 mt-4">No registration required. 100% Free.</p>
        </div>
      </div>
    </div>
  );
}
