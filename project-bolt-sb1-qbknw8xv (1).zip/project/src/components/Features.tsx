import { Brain, BookOpen, Scale, Bell, Globe, MessageSquare, Video, Download } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Smart Career Assessment',
    titleUrdu: 'ذہین کیریئر تشخیص',
    description: 'MBTI-style personality test combined with interest assessment to find your perfect career match with accurate fit percentages.',
    color: 'from-emerald-500 to-emerald-600'
  },
  {
    icon: BookOpen,
    title: 'Detailed Career Library',
    titleUrdu: 'تفصیلی کیریئر لائبریری',
    description: 'Explore 200+ career paths with step-by-step guidance, admission requirements, universities, and salary expectations.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: Scale,
    title: 'Career Comparison Tool',
    titleUrdu: 'کیریئر موازنہ ٹول',
    description: 'Compare up to 3 careers side by side based on duration, cost, job market demand, and earning potential.',
    color: 'from-emerald-600 to-blue-600'
  },
  {
    icon: Bell,
    title: 'Admission & Scholarship Alerts',
    titleUrdu: 'داخلہ اور وظائف الرٹس',
    description: 'Real-time notifications for admission openings, test dates, PEEF, HEC, Ehsaas scholarships and more.',
    color: 'from-blue-600 to-emerald-600'
  },
  {
    icon: Globe,
    title: 'International Scholarships',
    titleUrdu: 'بین الاقوامی وظائف',
    description: 'Discover fully funded scholarships in Turkey, UK, USA, China, Saudi Arabia with eligibility and application guides.',
    color: 'from-emerald-500 to-blue-500'
  },
  {
    icon: MessageSquare,
    title: 'AI Career Chatbot',
    titleUrdu: 'اے آئی کیریئر چیٹ بوٹ',
    description: 'Get instant answers in Urdu or English about careers, subjects, and guidance 24/7 from our smart assistant.',
    color: 'from-blue-500 to-emerald-500'
  },
  {
    icon: Video,
    title: 'Expert Consultations',
    titleUrdu: 'ماہرین سے مشاورت',
    description: 'Book one-on-one sessions with verified career counselors for personalized advice tailored to your goals.',
    color: 'from-emerald-600 to-blue-500'
  },
  {
    icon: Download,
    title: 'Offline Access',
    titleUrdu: 'آف لائن رسائی',
    description: 'Save your favorite careers, test results, and reading materials for access anytime, anywhere without internet.',
    color: 'from-blue-600 to-emerald-500'
  }
];

interface FeaturesProps {
  onNavigate: (page: string) => void;
}

export default function Features({ onNavigate }: FeaturesProps) {
  const handleFeatureClick = (title: string) => {
    if (title === 'Smart Career Assessment') {
      onNavigate('assessment');
    } else if (title === 'Detailed Career Library') {
      onNavigate('careers');
    } else if (title === 'Career Comparison Tool') {
      onNavigate('comparison');
    } else if (title === 'Admission & Scholarship Alerts' || title === 'International Scholarships') {
      onNavigate('scholarships');
    } else if (title === 'AI Career Chatbot') {
      onNavigate('chatbot');
    }
  };

  return (
    <div id="features" className="bg-white py-24 px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-16">
          <div className="inline-block bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold">
            Features
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900">
            Everything You Need to <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">Plan Your Future</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive tools and resources designed specifically for Pakistani students to make confident career decisions
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <button
              key={index}
              onClick={() => handleFeatureClick(feature.title)}
              className="group bg-white border-2 border-gray-100 rounded-2xl p-6 hover:border-emerald-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 cursor-pointer text-left"
            >
              <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-500 mb-3" dir="rtl">{feature.titleUrdu}</p>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </button>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-br from-emerald-50 to-blue-50 rounded-3xl p-8 lg:p-12">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">Bilingual Support</h3>
              <p className="text-xl text-gray-700 leading-relaxed" dir="rtl">
                اردو اور انگریزی دونوں زبانوں میں دستیاب
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Manzil is designed for Pakistani students with full support in both Urdu and English. Switch between languages anytime to learn comfortably in your preferred language.
              </p>
              <div className="flex gap-4">
                <div className="bg-white rounded-xl px-6 py-3 shadow-sm">
                  <p className="font-bold text-gray-900">اردو</p>
                </div>
                <div className="bg-white rounded-xl px-6 py-3 shadow-sm">
                  <p className="font-bold text-gray-900">English</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <span className="font-semibold text-gray-900">Language</span>
                  <button className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-4 py-2 rounded-lg font-semibold text-sm">
                    اردو / English
                  </button>
                </div>
                <div className="p-4 bg-emerald-50 rounded-xl">
                  <p className="text-gray-700 mb-2">Available in:</p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-white px-3 py-1 rounded-full text-sm font-medium text-gray-700">All Features</span>
                    <span className="bg-white px-3 py-1 rounded-full text-sm font-medium text-gray-700">Career Guides</span>
                    <span className="bg-white px-3 py-1 rounded-full text-sm font-medium text-gray-700">AI Chatbot</span>
                    <span className="bg-white px-3 py-1 rounded-full text-sm font-medium text-gray-700">Support</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
