import { Quote, Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Ahmed Hassan',
    nameUrdu: 'احمد حسن',
    role: 'Now studying MBBS at Dow Medical College',
    location: 'Karachi',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
    rating: 5,
    text: 'Manzil helped me realize that medicine was my true calling. The career assessment was so accurate, and the scholarship alerts helped me secure PEEF funding for my education.',
    textUrdu: 'منزل نے مجھے یہ سمجھنے میں مدد کی کہ طب میرا حقیقی مقصد ہے۔'
  },
  {
    name: 'Fatima Aslam',
    nameUrdu: 'فاطمہ اسلم',
    role: 'Computer Science student at NUST',
    location: 'Islamabad',
    image: 'https://images.pexels.com/photos/3772510/pexels-photo-3772510.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
    rating: 5,
    text: 'I was confused between Pre-Medical and ICS after Matric. Manzil showed me detailed comparisons and I chose Computer Science. Now I am at my dream university!',
    textUrdu: 'میں میٹرک کے بعد پری میڈیکل اور آئی سی ایس کے درمیان الجھن میں تھی۔'
  },
  {
    name: 'Bilal Khan',
    nameUrdu: 'بلال خان',
    role: 'Received scholarship to study in Turkey',
    location: 'Peshawar',
    image: 'https://images.pexels.com/photos/2102415/pexels-photo-2102415.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop',
    rating: 5,
    text: 'The international scholarship section changed my life. I found Turkiye Burslari through Manzil and now I am studying Engineering in Istanbul with full funding!',
    textUrdu: 'بین الاقوامی اسکالرشپ سیکشن نے میری زندگی بدل دی۔'
  }
];

export default function Testimonials() {
  return (
    <div id="testimonials" className="bg-white py-24 px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-16">
          <div className="inline-block bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold">
            Success Stories
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900">
            Real Students, <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">Real Success</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join thousands of Pakistani students who found their career direction with Manzil
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-2 border-gray-100"
            >
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>

              <Quote className="w-10 h-10 text-emerald-200 mb-4" />

              <p className="text-gray-700 leading-relaxed mb-4">
                "{testimonial.text}"
              </p>

              <p className="text-sm text-gray-500 mb-6" dir="rtl">
                "{testimonial.textUrdu}"
              </p>

              <div className="flex items-center gap-4 pt-4 border-t border-gray-200">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-14 h-14 rounded-full object-cover"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-gray-900">{testimonial.name}</p>
                    <span className="text-sm text-gray-500" dir="rtl">{testimonial.nameUrdu}</span>
                  </div>
                  <p className="text-sm text-emerald-600 font-medium">{testimonial.role}</p>
                  <p className="text-xs text-gray-500">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-emerald-500 to-blue-600 rounded-3xl p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Ready to Write Your Success Story?</h3>
          <p className="text-xl mb-8 text-emerald-50">Join 50,000+ students who found their path with Manzil</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-bold text-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all">
              Download for Android
            </button>
            <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all">
              Download for iOS
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
