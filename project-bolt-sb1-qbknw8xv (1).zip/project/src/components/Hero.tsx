import { Compass, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface HeroProps {
  onNavigate: (page: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="relative bg-gradient-to-br from-emerald-50 via-white to-blue-50 overflow-hidden">
      <nav className="relative z-10 px-6 py-4 lg:px-8">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Manzil</h1>
              <p className="text-xs text-gray-600 -mt-1">منزل</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">Features</a>
            <a href="#how-it-works" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">How It Works</a>
            <a href="#testimonials" className="text-gray-700 hover:text-emerald-600 transition-colors font-medium">Success Stories</a>
            <button className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-6 py-2.5 rounded-lg font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all">
              Download App
            </button>
          </div>

          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg border-t mt-2 py-4 px-6 space-y-4">
            <a href="#features" className="block text-gray-700 hover:text-emerald-600 font-medium">Features</a>
            <a href="#how-it-works" className="block text-gray-700 hover:text-emerald-600 font-medium">How It Works</a>
            <a href="#testimonials" className="block text-gray-700 hover:text-emerald-600 font-medium">Success Stories</a>
            <button className="w-full bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-6 py-2.5 rounded-lg font-semibold">
              Download App
            </button>
          </div>
        )}
      </nav>

      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="flex flex-wrap gap-3">
              <div className="bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold">
                🎓 For Matric & Intermediate Students
              </div>
              <div className="bg-gradient-to-r from-blue-500 to-emerald-500 text-white px-4 py-2 rounded-full text-sm font-semibold animate-pulse">
                ✨ FREE AI Career Chatbot Available!
              </div>
            </div>

            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Discover Yourself.<br />
                <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  Design Your Future.
                </span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed" dir="rtl">
                اپنے آپ کو دریافت کریں۔ اپنا مستقبل ڈیزائن کریں۔
              </p>
            </div>

            <p className="text-lg text-gray-700 leading-relaxed">
              Pakistan's first bilingual career guidance platform helping students make informed decisions about their future with personalized assessments, expert guidance, and scholarship opportunities.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => onNavigate('assessment')}
                className="bg-gradient-to-r from-emerald-500 to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all w-full sm:w-auto"
              >
                Take Free Career Test
              </button>
              <button
                onClick={() => onNavigate('chatbot')}
                className="border-2 border-blue-500 text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-500 hover:text-white transition-all w-full sm:w-auto"
              >
                Try AI Chatbot
              </button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <p className="text-3xl font-bold text-gray-900">50K+</p>
                <p className="text-sm text-gray-600">Students Guided</p>
              </div>
              <div className="w-px h-12 bg-gray-300"></div>
              <div>
                <p className="text-3xl font-bold text-gray-900">200+</p>
                <p className="text-sm text-gray-600">Career Paths</p>
              </div>
              <div className="w-px h-12 bg-gray-300"></div>
              <div>
                <p className="text-3xl font-bold text-gray-900">100%</p>
                <p className="text-sm text-gray-600">Free to Use</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-3xl transform rotate-3 opacity-20"></div>
            <div className="relative bg-white rounded-3xl shadow-2xl p-8 space-y-6">
              <div className="bg-gradient-to-br from-emerald-50 to-blue-50 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-gray-900">Your Career Match</h3>
                  <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-sm font-semibold">92%</span>
                </div>
                <div className="space-y-3">
                  <div className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-gray-900">Software Engineering</p>
                      <span className="text-emerald-600 font-bold">92%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-emerald-500 to-blue-600 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-gray-900">Business Administration</p>
                      <span className="text-blue-600 font-bold">85%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                  <div className="bg-white rounded-xl p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-gray-900">Data Science</p>
                      <span className="text-emerald-600 font-bold">78%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-emerald-50 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-emerald-700">5 mins</p>
                  <p className="text-sm text-gray-600">Quick Test</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 text-center">
                  <p className="text-2xl font-bold text-blue-700">Instant</p>
                  <p className="text-sm text-gray-600">Results</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-200 rounded-full filter blur-3xl opacity-30 -z-0"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-200 rounded-full filter blur-3xl opacity-30 -z-0"></div>
    </div>
  );
}
