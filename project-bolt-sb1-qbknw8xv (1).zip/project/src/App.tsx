import { useState } from 'react';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import Testimonials from './components/Testimonials';
import CTA from './components/CTA';
import Footer from './components/Footer';
import AssessmentPage from './pages/AssessmentPage';
import CareerLibraryPage from './pages/CareerLibraryPage';
import ComparisonPage from './pages/ComparisonPage';
import ScholarshipsPage from './pages/ScholarshipsPage';
import ChatbotPage from './pages/ChatbotPage';
import type { PageView } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<PageView>('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page as PageView);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setCurrentPage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (currentPage === 'assessment') {
    return <AssessmentPage onBack={handleBackToHome} />;
  }

  if (currentPage === 'careers') {
    return <CareerLibraryPage onBack={handleBackToHome} />;
  }

  if (currentPage === 'comparison') {
    return <ComparisonPage onBack={handleBackToHome} onOpenCareerLibrary={() => handleNavigate('careers')} />;
  }

  if (currentPage === 'scholarships') {
    return <ScholarshipsPage onBack={handleBackToHome} />;
  }

  if (currentPage === 'chatbot') {
    return <ChatbotPage onBack={handleBackToHome} />;
  }

  return (
    <div className="min-h-screen bg-white">
      <Hero onNavigate={handleNavigate} />
      <Features onNavigate={handleNavigate} />
      <HowItWorks />
      <Testimonials />
      <CTA />
      <Footer />
    </div>
  );
}

export default App;
