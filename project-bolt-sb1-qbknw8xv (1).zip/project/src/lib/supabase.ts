import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function getSessionId(): string {
  let sessionId = localStorage.getItem('manzil_session_id');
  if (!sessionId) {
    sessionId = generateSessionId();
    localStorage.setItem('manzil_session_id', sessionId);
  }
  return sessionId;
}
